//
//  LYPlayerView.swift
//  takeEasy
//
//  Created by Gordon on 2017/8/11.
//  Copyright © 2017年 Gordon. All rights reserved.
//

import UIKit

class LYPlayerView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
