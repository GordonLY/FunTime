//
//  NotiName+LYDevelop.swift
//  takeEasy
//
//  Created by Gordon on 2017/8/11.
//  Copyright © 2017年 Gordon. All rights reserved.
//

import Foundation

extension Notification.Name {
    
    public static let ly_AppDidReceiveRemoteControlNotification: NSNotification.Name = NSNotification.Name(rawValue: "ly_AppDidReceiveRemoteControlNotification")
}
